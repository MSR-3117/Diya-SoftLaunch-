from app import create_app

app = create_app()

# Vercel looks for 'app' variable by default
